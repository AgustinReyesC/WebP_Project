pagina web de un sitio de venta de lo que queramos. Este proyecto fué hecho como una tarea.
